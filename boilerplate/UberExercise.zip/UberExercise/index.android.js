import App from './app'
import { AppRegistry } from 'react-native'

AppRegistry.registerComponent('UberExercise', () => App)
