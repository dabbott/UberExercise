import React, { Component, PropTypes } from 'react'
import { StyleSheet, View, Text, Image, Dimensions } from 'react-native'
import * as Animatable from 'react-native-animatable'

import LocationButton from './LocationButton'

export default class LocationButtonGroup extends Component {

  render() {
    return null
  }
}

const styles = StyleSheet.create({

})
