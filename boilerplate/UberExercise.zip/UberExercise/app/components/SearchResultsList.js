import React, { Component } from 'react'
import { ListView, View, Text, StyleSheet } from 'react-native'

import SearchResultsRow from './SearchResultsRow'

export default class SearchResultsList extends Component {

  render() {
    return null
  }
}

const styles = StyleSheet.create({

})
