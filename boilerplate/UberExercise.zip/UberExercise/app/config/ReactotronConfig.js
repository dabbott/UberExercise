import Reactotron from 'reactotron-react-native'

Reactotron
  .configure()
  .connect()
