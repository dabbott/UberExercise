export default {
  hamburger: require('../images/icon-hamburger.png'),
  home: require('../images/icon-home.png'),
  recent: require('../images/icon-recent.png'),
  'arrow-left': require('../images/icon-arrow-left.png'),
}
